﻿using System;
using System.Net;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization;

namespace HackerNews
{
    public class Program
    {

        public static string[] itemIDsTop500;               //array of top 500 item IDs only
        public static Item[] top500Items = new Item[500];   //object array of top 500 items
        public static int InputRecordCounter = 0;
        public static string ErrorMessage = " ";
        public static Item[] formattedData = new Item[500];

        [STAThread]
        public static void Main()
        {
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());

            //Housekeeping
            for (int i = 0; i < formattedData.Length; i++)
            {
                formattedData[i] = new Item();
            }
            //Taken all ItemIDs from URL and placed in Array itemIDsTop500
            var top500ItemNumbers = new WebClient();
            var top500NewsStories = top500ItemNumbers.DownloadString("https://hacker-news.firebaseio.com/v0/newstories.json");
            string[] stringSeparatorsRaw = { "[", "]", "," };
            itemIDsTop500 = top500NewsStories.Split(stringSeparatorsRaw, StringSplitOptions.RemoveEmptyEntries);

            var items = new WebClient();
            Console.WriteLine("\r\n");
            Console.WriteLine("\r\n");
            Console.WriteLine("Please Wait....about 20 seconds....");
            //Process each JSON input and create Item classes and store in table
            for (int i = 0; i < itemIDsTop500.Length; i++)
            {
                string[] stringSeparatorsJson = { "{", "\":", "[", "]", ",", "}" };
                var anItem = items.DownloadString($"https://hacker-news.firebaseio.com/v0/item/{itemIDsTop500[i]}.json");
                string[] parts = anItem.Split(stringSeparatorsJson, StringSplitOptions.RemoveEmptyEntries);
                Item workingItem = new Item();
                //Load parts of each record
                LoadAnItem(parts, workingItem);
                //Load table of data now structured
                formattedData[InputRecordCounter] = workingItem;
                InputRecordCounter++;
            }

            //Display all Author/Title data
            Console.WriteLine("Author & Title data to follow of current best stories on Hacker News");
            Console.WriteLine($"{"Author",-17}" + $"{"Title",-10}");
            Console.WriteLine($"{"------",-17}" + $"{"-----",-10}");
            for (int i = 0; i < formattedData.Length; i++)
            {
                Console.WriteLine($"{formattedData[i].By,-17}" +
                    $"{formattedData[i].Title,-10}");
            }

            //Totals Check
            Console.WriteLine("\r\n");
            Console.WriteLine("Total Input Records Processed: " + InputRecordCounter);
        }

        private static void LoadAnItem(string[] workTheParts, Item workingItem)
        {
            string pattern = "\"*\"";
            string replacement = "";
            var tempPart = " ";
            var tempString = " ";
            Regex rgx = new Regex(pattern);
            for (int i = 0; i < workTheParts.Length; i++)
            {
                switch (workTheParts[i])
                {
                    case "\"id":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.ItemIDItems = tempPart;
                        break;

                    case "\"deleted":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Deleted = Boolean.Parse(tempPart);
                        break;

                    case "\"type":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.ItemType = tempPart;
                        break;

                    case "\"by":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.By = tempPart;
                        break;

                    case "\"time":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.CreateDateItem = Int32.Parse(tempPart);
                        break;

                    case "\"text":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Text = tempPart;
                        break;

                    case "\"dead":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Dead = Boolean.Parse(tempPart);
                        break;

                    case "\"parent":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Parent = tempPart;
                        break;

                    case "\"poll":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Poll = tempPart;
                        break;

                    case "\"kids":

                        break;

                    case "\"url":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Url = tempPart;
                        break;

                    case "\"score":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Score = Int32.Parse(tempPart);
                        break;

                    case "\"title":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Title = tempPart;
                        break;

                    case "\"arts":

                        break;

                    case "\"descendants":
                        i++;
                        tempString = workTheParts[i];
                        tempPart = rgx.Replace(tempString, replacement);
                        workingItem.Descendants = Int32.Parse(tempPart);
                        break;

                    default:
                        ErrorMessage = "Fall through Case statement - no known field";
                        break;
                }
            }

        }

        public class Item 
        {
            public string ItemIDItems { get; set; }  //The item's unique id.
            public bool Deleted { get; set; }        //true if the item is deleted.
            public string ItemType { get; set; }     //The type of item. One of "job", "story", "comment", "poll", or "pollopt".
            public string By { get; set; }           //The username of the item's author.
            public long CreateDateItem { get; set; } //Creation date of the item, in Unix Time.
            public string Text { get; set; }         //The comment, story or poll text. HTML.
            public bool Dead { get; set; }           //true if the item is dead.
            public string Parent { get; set; }       //Comment's parent; either another comment of the relevent story
            public string Poll { get; set; }         //pollopt's associated poll
            public string[] Kids { get; set; }       //The ids of the item's comments, in ranked display order
            public string Url { get; set; }          //The URL of the story
            public int Score { get; set; }           //The story's score or the votes for the pollopt
            public string Title { get; set; }        //The title of the story, poll or job
            public string[] Parts { get; set; }      //A list of related pollopts, in display order
            public int Descendants { get; set; }     //In the case of stories or polls, the total comment count
        }

        public class User
        {
            public string ItemIDUser { get; set; }   //The user's unique username. Case-Sensitive.Required.
            public int Delay { get; set; }           //Delay in minutes between a comment's creation and its visibility to other users
            public long CreateDateUser { get; set; } //Creation date of the user in Unix Time
            public string Karma { get; set; }        //User's karma
            public string About { get; set; }        //The user's optional self-description. HTML
            public string[] Submitted { get; set; }  //List of the user's stories, polls and comments
        }
    }
}

