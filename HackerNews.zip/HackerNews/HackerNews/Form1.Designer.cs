﻿namespace HackerNews
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.AuthorColumnHeader = new System.Windows.Forms.TextBox();
            this.TitleColumnHeader = new System.Windows.Forms.TextBox();
            this.SelectStoriesComboBox = new System.Windows.Forms.ComboBox();
            this.AuthorList = new System.Windows.Forms.ListView();
            this.TitleList = new System.Windows.Forms.ListView();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.AuthorColumnHeader);
            this.panel1.Location = new System.Drawing.Point(4, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(684, 31);
            this.panel1.TabIndex = 1;
            // 
            // AuthorColumnHeader
            // 
            this.AuthorColumnHeader.Location = new System.Drawing.Point(5, 5);
            this.AuthorColumnHeader.Name = "AuthorColumnHeader";
            this.AuthorColumnHeader.Size = new System.Drawing.Size(207, 20);
            this.AuthorColumnHeader.TabIndex = 0;
            this.AuthorColumnHeader.Text = "Author";
            // 
            // TitleColumnHeader
            // 
            this.TitleColumnHeader.Location = new System.Drawing.Point(222, 35);
            this.TitleColumnHeader.Name = "TitleColumnHeader";
            this.TitleColumnHeader.Size = new System.Drawing.Size(466, 20);
            this.TitleColumnHeader.TabIndex = 1;
            this.TitleColumnHeader.Text = "Title";
            // 
            // SelectStoriesComboBox
            // 
            this.SelectStoriesComboBox.AccessibleDescription = "";
            this.SelectStoriesComboBox.AccessibleName = "SelectStoriesComboBox";
            this.SelectStoriesComboBox.FormattingEnabled = true;
            this.SelectStoriesComboBox.Items.AddRange(new object[] {
            "Top 500 New, Top & Best Stories",
            "200 of the Latest Ask HN Stories",
            "200 of the Latest Show HN Stories",
            "200 of the Latest Job Stories"});
            this.SelectStoriesComboBox.Location = new System.Drawing.Point(4, 3);
            this.SelectStoriesComboBox.Name = "SelectStoriesComboBox";
            this.SelectStoriesComboBox.Size = new System.Drawing.Size(512, 21);
            this.SelectStoriesComboBox.TabIndex = 2;
            this.SelectStoriesComboBox.Text = "Select Stories";
            // 
            // AuthorList
            // 
            this.AuthorList.Location = new System.Drawing.Point(6, 69);
            this.AuthorList.Name = "AuthorList";
            this.AuthorList.Size = new System.Drawing.Size(162, 421);
            this.AuthorList.TabIndex = 3;
            this.AuthorList.UseCompatibleStateImageBehavior = false;
            // 
            // TitleList
            // 
            this.TitleList.Location = new System.Drawing.Point(177, 69);
            this.TitleList.Name = "TitleList";
            this.TitleList.Size = new System.Drawing.Size(511, 421);
            this.TitleList.TabIndex = 4;
            this.TitleList.UseCompatibleStateImageBehavior = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(697, 492);
            this.Controls.Add(this.TitleColumnHeader);
            this.Controls.Add(this.TitleList);
            this.Controls.Add(this.AuthorList);
            this.Controls.Add(this.SelectStoriesComboBox);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TitleColumnHeader;
        private System.Windows.Forms.TextBox AuthorColumnHeader;
        private System.Windows.Forms.ComboBox SelectStoriesComboBox;
        private System.Windows.Forms.ListView AuthorList;
        private System.Windows.Forms.ListView TitleList;
    }
}

